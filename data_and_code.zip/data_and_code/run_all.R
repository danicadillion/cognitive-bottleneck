project_root <- local({
  configured <- getOption("bottleneck.project_root")
  source_files <- unlist(lapply(rev(sys.frames()), function(frame) frame$ofile))
  command_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  candidates <- unique(c(configured, source_files, command_file, getwd()))
  found <- NULL
  for (candidate in candidates) {
    if (!file.exists(candidate)) next
    directory <- normalizePath(if (dir.exists(candidate)) candidate else dirname(candidate), winslash = "/")
    repeat {
      if (file.exists(file.path(directory, "Cognitive_Bottlenecks.Rproj"))) {
        found <- directory
        break
      }
      parent <- dirname(directory)
      if (identical(parent, directory)) break
      directory <- parent
    }
    if (!is.null(found)) break
  }
  if (is.null(found)) stop("Open Cognitive_Bottlenecks.Rproj or run this script from the extracted project.")
  found
})
source(file.path(project_root, "R", "project_utils.R"), local = TRUE)

require_packages(project_packages)
options(bottleneck.project_root = project_root)
scripts <- c("cognitive_alignment/cognitive_alignment.R",
             "predictive_alignment/mlp.R", "predictive_alignment/regression.R",
             "predictive_alignment/unsupervised.R",
             "bottleneck_evaluations/bottleneck_evaluations.R",
             "explanation_quality/explanation_quality.R")
log_dir <- results_dir("logs")
for (script in scripts) {
  message("Running ", script)
  log_path <- file.path(log_dir, paste0(tools::file_path_sans_ext(basename(script)), ".txt"))
  connection <- file(log_path, open = "wt", encoding = "UTF-8")
  sink(connection)
  tryCatch(
    sys.source(project_path("analyses", script), envir = new.env(parent = globalenv())),
    finally = { sink(); close(connection) }
  )
}
writeLines(capture.output(sessionInfo()), project_path("results", "session_info.txt"))
message("All analyses completed. Results are in the project's results folder.")
