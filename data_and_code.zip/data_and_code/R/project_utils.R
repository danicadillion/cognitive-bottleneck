project_path <- function(...) file.path(project_root, ...)

results_dir <- function(...) {
  directory <- project_path("results", ...)
  dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  directory
}

project_packages <- c("dplyr", "tidyr", "purrr", "tibble", "ggplot2",
                      "stringr", "lme4", "lmerTest", "effsize", "lavaan")

require_packages <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) stop("Missing packages: ", paste(missing, collapse = ", "),
                            ". Run setup.R from the project first.")
}

read_csv_robust <- function(path, check.names = FALSE) {
  prefix <- readBin(path, "raw", 3L)
  encoding <- if (identical(prefix, as.raw(c(0xEF, 0xBB, 0xBF)))) {
    "UTF-8-BOM"
  } else if (all(validUTF8(readLines(path, warn = FALSE)))) {
    "UTF-8"
  } else {
    "latin1"
  }
  read.csv(path, check.names = check.names, na.strings = c("", "NA", "NaN"),
           fileEncoding = encoding, stringsAsFactors = FALSE)
}
