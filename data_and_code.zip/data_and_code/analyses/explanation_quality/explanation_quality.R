# Human evaluations of baseline and bottleneck explanations.
project_root <- local({
  configured <- getOption("bottleneck.project_root")
  source_files <- unlist(lapply(rev(sys.frames()), function(frame) frame$ofile))
  command_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  candidates <- unique(c(configured, source_files, command_file, getwd()))
  found <- NULL
  for (candidate in candidates) {
    if (!file.exists(candidate)) next
    directory <- normalizePath(if (dir.exists(candidate)) candidate else dirname(candidate), winslash = "/")
    repeat {
      if (file.exists(file.path(directory, "Cognitive_Bottlenecks.Rproj"))) {
        found <- directory
        break
      }
      parent <- dirname(directory)
      if (identical(parent, directory)) break
      directory <- parent
    }
    if (!is.null(found)) break
  }
  if (is.null(found)) stop("Open Cognitive_Bottlenecks.Rproj or run this script from the extracted project.")
  found
})
source(file.path(project_root, "R", "project_utils.R"), local = TRUE)

require_packages(c("dplyr", "tidyr", "purrr", "tibble", "ggplot2", "stringr", "lme4", "lmerTest"))
library(dplyr)
library(tidyr)
library(purrr)
library(tibble)
library(ggplot2)
library(stringr)
library(lme4)
library(lmerTest)

data_path <- project_path("data", "explanation_quality", "explanation_quality_human_ratings.csv")
explanation_path <- project_path("data", "explanation_quality", "bottleneck_explanation_texts.csv")
output_dir <- results_dir("explanation_quality")

raw <- read.csv(data_path, check.names = FALSE, stringsAsFactors = FALSE)

raw <- raw %>%
  filter(
    !is.na(suppressWarnings(as.numeric(botcatch_2))) |
      botcatch_2 == "" | is.na(botcatch_2)
  ) %>%
  mutate(
    botcatch_2 = suppressWarnings(as.numeric(botcatch_2)),
    botcatch_1 = suppressWarnings(as.numeric(botcatch_1)),
    pid = factor(row_number())
  )

cat("Rows read:", nrow(raw), "\n")

raw <- raw %>%
  mutate(
    pass_bot_start = botcatch_2 == 1,
    pass_bot_end = botcatch_1 == 1
  )

cat("\n--- Bot check pass rates ---\n")
cat("Pass start check (botcatch_2):", sum(raw$pass_bot_start, na.rm = TRUE), "\n")
cat("Pass end check   (botcatch_1):", sum(raw$pass_bot_end, na.rm = TRUE), "\n")

dat <- raw %>%
  filter(pass_bot_start %in% TRUE, pass_bot_end %in% TRUE)

cat("Retained after exclusions:", nrow(dat), "of", nrow(raw), "\n")
if (nrow(dat) != 404) {
  warning("Expected 404 retained participants, but found ", nrow(dat), ".")
}

load_explanation_lengths <- function(csv_path) {
  texts <- read.csv(
    csv_path,
    fileEncoding = "UTF-8",
    colClasses = "character",
    check.names = FALSE,
    stringsAsFactors = FALSE
  )

  required_columns <- c("scenario", "condition", "explanation_text")
  missing_columns <- setdiff(required_columns, names(texts))
  if (length(missing_columns) > 0L) {
    stop(
      "Explanation text CSV is missing required column(s): ",
      paste(missing_columns, collapse = ", ")
    )
  }

  texts <- as_tibble(texts) %>% select(all_of(required_columns))
  if (
    nrow(texts) != 140L ||
      n_distinct(texts$scenario) != 70L ||
      anyNA(texts) ||
      any(!str_detect(texts$scenario, "^[0-9]+$")) ||
      any(!(texts$condition %in% c("baseline", "bottleneck"))) ||
      any(!nzchar(str_trim(texts$explanation_text)))
  ) {
    stop(
      "Invalid explanation text CSV. Expected 140 nonmissing explanations ",
      "across 70 numeric scenario IDs, with conditions baseline and bottleneck."
    )
  }

  condition_counts <- texts %>% count(scenario, condition)
  if (nrow(condition_counts) != 140L || any(condition_counts$n != 1L)) {
    stop("Each scenario must have one baseline and one bottleneck text.")
  }

  explanation_text <- texts$explanation_text

  word_lists <- str_extract_all(
    explanation_text,
    "[[:alnum:]’'-]+"
  )

  text_lengths <- tibble(
    scenario = texts$scenario,
    condition = texts$condition,
    explanation_text = explanation_text,
    text_words = vapply(word_lists, length, integer(1)),
    text_characters = nchar(explanation_text)
  )

  if (any(text_lengths$text_words <= 0)) {
    stop("Every explanation must have a positive word count.")
  }

  text_lengths
}

text_lengths <- load_explanation_lengths(explanation_path)

cat("\n--- Explanation text lengths ---\n")
print(
  text_lengths %>%
    group_by(condition) %>%
    summarise(
      mean_words = mean(text_words),
      sd_words = sd(text_words),
      min_words = min(text_words),
      max_words = max(text_words),
      .groups = "drop"
    )
)

length_condition_correlation <- text_lengths %>%
  mutate(cond_bn = as.integer(condition == "bottleneck")) %>%
  summarise(r = cor(cond_bn, text_words)) %>%
  pull(r)

cat(
  "Correlation between bottleneck condition and word count:",
  round(length_condition_correlation, 3), "\n"
)

write.csv(
  text_lengths,
  file.path(output_dir, "bottleneck_explanation_text_lengths.csv"),
  row.names = FALSE
)

dim_labels <- c(
  "1" = "Thoughtful",
  "2" = "Agree",
  "3" = "Trust writer",
  "4" = "Clear reasoning",
  "5" = "Morally correct"
)

long <- dat %>%
  dplyr::select(
    pid,
    matches("^o_\\d+_(dyadic|baseline)_[1-5]$")
  ) %>%
  pivot_longer(
    cols = -pid,
    names_to = c("scenario", "source_condition", "dimension"),
    names_pattern = "^o_(\\d+)_(dyadic|baseline)_([1-5])$",
    values_to = "rating"
  ) %>%
  mutate(
    rating = suppressWarnings(as.numeric(rating)),
    condition = if_else(
      source_condition == "dyadic",
      "bottleneck",
      "baseline"
    )
  ) %>%
  filter(!is.na(rating)) %>%
  left_join(text_lengths, by = c("scenario", "condition")) %>%
  mutate(
    scenario = factor(scenario),
    condition = factor(
      condition,
      levels = c("baseline", "bottleneck")
    ),
    cond_bn = as.integer(condition == "bottleneck"),
    dim_label = factor(dim_labels[dimension], levels = dim_labels),
    
    text_words_10 = (
      text_words - mean(text_lengths$text_words)
    ) / 10
  )

expected_long_n <- nrow(dat) * 5 * 2 * 5
if (nrow(long) != expected_long_n) {
  stop(
    "Long-format observation count mismatch: found ", nrow(long),
    ", expected ", expected_long_n, "."
  )
}
if (anyNA(long$text_words) || anyNA(long$explanation_text)) {
  stop("At least one rating failed to match an explanation.")
}
stopifnot(all(long$rating %in% 1:7))

cat("\nLong-format observations:", nrow(long), "\n")

desc <- long %>%
  mutate(
    system = recode(
      as.character(condition),
      "baseline" = "Baseline (CoT)",
      "bottleneck" = "Bottleneck + CoT"
    )
  ) %>%
  group_by(dim_label, system) %>%
  summarise(
    mean = mean(rating),
    sd = sd(rating),
    n_ratings = n(),
    n_participants = n_distinct(pid),
    n_scenarios = n_distinct(scenario),
    .groups = "drop"
  )

cat("\n--- Descriptives ---\n")
print(desc, n = Inf)

dz_tab <- long %>%
  group_by(dim_label, pid, condition) %>%
  summarise(participant_mean = mean(rating), .groups = "drop") %>%
  pivot_wider(names_from = condition, values_from = participant_mean) %>%
  mutate(diff = bottleneck - baseline) %>%
  group_by(dim_label) %>%
  summarise(dz = mean(diff) / sd(diff), .groups = "drop") %>%
  transmute(dimension = as.character(dim_label), dz)

make_model_formulas <- function(adjust_for_length = FALSE) {
  fixed_terms <- if (adjust_for_length) {
    "cond_bn + text_words_10"
  } else {
    "cond_bn"
  }

  random_terms <- c(
    max = "(1 + cond_bn | pid) + (1 + cond_bn | scenario)",
    no_corr = "(1 + cond_bn || pid) + (1 + cond_bn || scenario)",
    scenario_slope = "(1 | pid) + (1 + cond_bn || scenario)",
    participant_slope = "(1 + cond_bn || pid) + (1 | scenario)",
    intercepts = "(1 | pid) + (1 | scenario)"
  )

  map(
    random_terms,
    ~ as.formula(
      paste("rating ~", fixed_terms, "+", .x),
      env = parent.frame()
    )
  )
}

fit_one_candidate <- function(formula, df) {
  captured_notes <- character()

  model <- tryCatch(
    withCallingHandlers(
      lmerTest::lmer(
        formula,
        data = df,
        control = lmerControl(
          optimizer = "bobyqa",
          optCtrl = list(maxfun = 2e5)
        )
      ),
      warning = function(w) {
        captured_notes <<- c(captured_notes, conditionMessage(w))
        invokeRestart("muffleWarning")
      },
      message = function(m) {
        captured_notes <<- c(captured_notes, conditionMessage(m))
        invokeRestart("muffleMessage")
      }
    ),
    error = function(e) e
  )

  if (inherits(model, "error")) {
    return(list(
      model = NULL,
      ok = FALSE,
      singular = NA,
      diagnostics = conditionMessage(model)
    ))
  }

  singular <- isSingular(model, tol = 1e-4)
  convergence_messages <- model@optinfo$conv$lme4$messages
  optimizer_code <- model@optinfo$conv$opt

  optimizer_ok <- length(optimizer_code) == 0 || all(optimizer_code == 0)
  convergence_ok <- length(convergence_messages) == 0
  warning_indicates_failure <- any(
    str_detect(
      captured_notes,
      regex(
        "failed to converge|unable to evaluate|degenerate Hessian",
        ignore_case = TRUE
      )
    )
  )

  diagnostics <- unique(c(captured_notes, convergence_messages))
  if (singular) diagnostics <- c(diagnostics, "singular fit")
  diagnostics <- paste(
    unique(diagnostics[nzchar(diagnostics)]),
    collapse = " | "
  )

  list(
    model = model,
    ok = !singular &&
      optimizer_ok &&
      convergence_ok &&
      !warning_indicates_failure,
    singular = singular,
    diagnostics = diagnostics
  )
}

fit_dimension <- function(
    df,
    adjust_for_length = FALSE,
    dimension_name = "") {
  formulas <- make_model_formulas(adjust_for_length)
  fit_cache <- list()

  evaluate_candidate <- function(candidate_name) {
    fit <- fit_one_candidate(formulas[[candidate_name]], df)
    fit_cache[[candidate_name]] <<- fit

    if (!fit$ok) {
      detail <- ifelse(
        nzchar(fit$diagnostics),
        fit$diagnostics,
        "unknown failure"
      )
      message(
        "Rejected ", candidate_name, " model for ",
        dimension_name, ": ", detail
      )
    }
    fit
  }

  max_fit <- evaluate_candidate("max")
  if (max_fit$ok) {
    return(list(
      model = max_fit$model,
      structure = "max",
      diagnostics = max_fit$diagnostics
    ))
  }

  no_corr_fit <- evaluate_candidate("no_corr")
  if (no_corr_fit$ok) {
    return(list(
      model = no_corr_fit$model,
      structure = "no_corr",
      diagnostics = no_corr_fit$diagnostics
    ))
  }

  reduced_names <- c("scenario_slope", "participant_slope")
  reduced_fits <- set_names(
    map(reduced_names, evaluate_candidate),
    reduced_names
  )
  viable_reduced <- keep(reduced_fits, ~ .x$ok)

  if (length(viable_reduced) > 0) {
    candidate_aic <- map_dbl(viable_reduced, ~ AIC(.x$model))
    selected_name <- names(which.min(candidate_aic))
    selected <- viable_reduced[[selected_name]]

    message(
      "Selected ", selected_name, " model for ", dimension_name,
      " after richer structures failed."
    )
    return(list(
      model = selected$model,
      structure = selected_name,
      diagnostics = selected$diagnostics
    ))
  }

  intercept_fit <- evaluate_candidate("intercepts")
  if (intercept_fit$ok) {
    return(list(
      model = intercept_fit$model,
      structure = "intercepts",
      diagnostics = intercept_fit$diagnostics
    ))
  }

  all_diagnostics <- imap_chr(
    fit_cache,
    ~ paste0(
      .y, ": ",
      ifelse(nzchar(.x$diagnostics), .x$diagnostics, "failed")
    )
  )
  stop(
    "No nonsingular, converged model was available for ",
    dimension_name, ". Candidate diagnostics: ",
    paste(all_diagnostics, collapse = "; ")
  )
}

dimension_data <- long %>%
  group_split(dim_label)
names(dimension_data) <- map_chr(
  dimension_data,
  ~ as.character(.x$dim_label[1])
)

cat("\n--- Fitting primary models ---\n")
primary_fits <- imap(
  dimension_data,
  ~ fit_dimension(
    .x,
    adjust_for_length = FALSE,
    dimension_name = paste0(.y, " [primary]")
  )
)

cat("\n--- Fitting text-length-adjusted models ---\n")
length_adjusted_fits <- imap(
  dimension_data,
  ~ fit_dimension(
    .x,
    adjust_for_length = TRUE,
    dimension_name = paste0(.y, " [length-adjusted]")
  )
)

extract_effect <- function(model, term) {
  coefficient_table <- summary(model)$coefficients
  row_i <- which(rownames(coefficient_table) == term)
  if (length(row_i) != 1) {
    stop("Expected exactly one coefficient named '", term, "'.")
  }

  estimate <- unname(coefficient_table[row_i, "Estimate"])
  std_error <- unname(coefficient_table[row_i, "Std. Error"])

  if ("df" %in% colnames(coefficient_table)) {
    df_value <- unname(coefficient_table[row_i, "df"])
    statistic <- unname(coefficient_table[row_i, "t value"])
    p_value <- unname(coefficient_table[row_i, "Pr(>|t|)"])
  } else {
    df_value <- NA_real_
    statistic <- estimate / std_error
    p_value <- 2 * pnorm(-abs(statistic))
  }

  critical_value <- ifelse(
    is.na(df_value),
    qnorm(0.975),
    qt(0.975, df_value)
  )

  tibble(
    b = estimate,
    se = std_error,
    ci_lo = estimate - critical_value * std_error,
    ci_hi = estimate + critical_value * std_error,
    df = df_value,
    t = statistic,
    p = p_value
  )
}

summarise_fit_set <- function(fits, term, model_spec, effect_label) {
  imap_dfr(fits, function(fit, dimension_name) {
    extract_effect(fit$model, term) %>%
      mutate(
        dimension = dimension_name,
        model_spec = model_spec,
        effect = effect_label,
        re_structure = fit$structure,
        fit_diagnostics = fit$diagnostics,
        .before = 1
      )
  })
}

results <- bind_rows(
  summarise_fit_set(
    primary_fits,
    term = "cond_bn",
    model_spec = "primary_unadjusted",
    effect_label = "bottleneck_plus_cot_vs_cot"
  ),
  summarise_fit_set(
    length_adjusted_fits,
    term = "cond_bn",
    model_spec = "adjusted_for_text_length",
    effect_label = "bottleneck_plus_cot_vs_cot"
  ),
  summarise_fit_set(
    length_adjusted_fits,
    term = "text_words_10",
    model_spec = "adjusted_for_text_length",
    effect_label = "text_length_per_10_words"
  )
) %>%
  group_by(model_spec, effect) %>%
  mutate(p_holm = p.adjust(p, method = "holm")) %>%
  ungroup() %>%
  left_join(dz_tab, by = "dimension") %>%
  mutate(
    dz = if_else(effect == "bottleneck_plus_cot_vs_cot", dz, NA_real_)
  ) %>%
  select(
    model_spec, effect, dimension, re_structure, fit_diagnostics,
    b, se, ci_lo, ci_hi, df, t, p, p_holm, dz
  )

cat("\n--- Primary and text-length-adjusted results ---\n")
cat(
  "For bottleneck_plus_cot_vs_cot, b > 0 means Bottleneck + CoT ",
  "was rated higher than Baseline (CoT).\n",
  sep = ""
)
cat("For text_length_per_10_words, b is change per 10 additional words.\n\n")
print(
  results %>% mutate(across(where(is.numeric), ~ round(.x, 4))),
  n = Inf
)

cat(
  "\n--- TEXT-LENGTH-CONTROLLED: Bottleneck + CoT versus ",
  "Baseline (CoT) ---\n",
  sep = ""
)
print(
  results %>%
    filter(
      model_spec == "adjusted_for_text_length",
      effect == "bottleneck_plus_cot_vs_cot"
    ) %>%
    select(dimension, re_structure, b, se, ci_lo, ci_hi, df, t, p, p_holm) %>%
    mutate(across(where(is.numeric), ~ round(.x, 4))),
  n = Inf
)

cat("\n--- Text-length coefficient within the controlled models ---\n")
print(
  results %>%
    filter(effect == "text_length_per_10_words") %>%
    select(dimension, b, se, ci_lo, ci_hi, df, t, p, p_holm) %>%
    mutate(across(where(is.numeric), ~ round(.x, 4))),
  n = Inf
)

write.csv(
  results,
  file.path(output_dir, "explanation_model_results.csv"),
  row.names = FALSE
)

print_model_summaries <- function(fits, heading) {
  cat(
    "\n\n#################### ", heading,
    " ####################\n",
    sep = ""
  )
  walk2(fits, names(fits), function(fit, dimension_name) {
    cat(
      "\n========== ", dimension_name,
      " [", fit$structure, "] ==========\n",
      sep = ""
    )
    print(summary(fit$model))
  })
}

print_model_summaries(primary_fits, "PRIMARY MODELS")
print_model_summaries(
  length_adjusted_fits,
  "TEXT-LENGTH-ADJUSTED MODELS"
)

plot_dat <- long %>%
  group_by(dim_label, pid, condition) %>%
  summarise(participant_mean = mean(rating), .groups = "drop") %>%
  group_by(dim_label, condition) %>%
  summarise(
    mean = mean(participant_mean),
    se = sd(participant_mean) / sqrt(n()),
    .groups = "drop"
  )

condition_colors <- c(
  "baseline" = "#2457FF",
  "bottleneck" = "#FF2B2B"
)

p_means <- ggplot(
  plot_dat,
  aes(x = dim_label, y = mean, fill = condition)
) +
  geom_col(
    position = position_dodge(0.80),
    width = 0.70,
    color = "black"
  ) +
  geom_errorbar(
    aes(ymin = mean - se, ymax = mean + se),
    position = position_dodge(0.80),
    width = 0.18
  ) +
  coord_cartesian(ylim = c(1, 7)) +
  scale_fill_manual(
    values = condition_colors,
    labels = c("Baseline (CoT)", "Bottleneck + CoT")
  ) +
  labs(
    x = NULL,
    y = "Mean rating (1-7)",
    fill = "Explanation",
    title = "Baseline (CoT) versus Bottleneck + CoT explanations",
    subtitle = "Bars show participant means +/- 1 SE"
  ) +
  theme_classic(base_size = 13) +
  theme(
    text = element_text(color = "black"),
    plot.title = element_text(face = "bold", color = "black"),
    plot.subtitle = element_text(color = "black"),
    axis.title = element_text(color = "black"),
    axis.text = element_text(color = "black"),
    legend.title = element_text(color = "black"),
    legend.text = element_text(color = "black")
  )

print(p_means)
ggsave(
  file.path(output_dir, "cot_vs_bottleneck_plus_cot_means.png"),
  p_means,
  width = 9,
  height = 5.5,
  dpi = 300
)

effect_plot_dat <- results %>%
  filter(effect == "bottleneck_plus_cot_vs_cot") %>%
  mutate(
    dimension = factor(dimension, levels = dim_labels),
    model_spec = factor(
      model_spec,
      levels = c("primary_unadjusted", "adjusted_for_text_length"),
      labels = c("Primary", "Adjusted for text length")
    )
  )

p_effects <- ggplot(
  effect_plot_dat,
  aes(x = dimension, y = b, color = model_spec)
) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "gray55"
  ) +
  geom_errorbar(
    aes(ymin = ci_lo, ymax = ci_hi),
    position = position_dodge(width = 0.48),
    width = 0.14,
    linewidth = 0.7
  ) +
  geom_point(
    position = position_dodge(width = 0.48),
    size = 2.8
  ) +
  scale_color_manual(values = c("#222222", "#D55E00")) +
  labs(
    x = NULL,
    y = "Bottleneck + CoT minus Baseline (CoT) rating",
    color = NULL,
    title = "Estimated advantage of Bottleneck + CoT over Baseline (CoT)",
    subtitle = "Mixed-model estimates with 95% confidence intervals"
  ) +
  theme_classic(base_size = 13) +
  theme(
    text = element_text(color = "black"),
    plot.title = element_text(face = "bold", color = "black"),
    plot.subtitle = element_text(color = "black"),
    axis.title = element_text(color = "black"),
    axis.text = element_text(color = "black"),
    axis.text.x = element_text(angle = 20, hjust = 1, color = "black"),
    legend.text = element_text(color = "black")
  )

print(p_effects)
ggsave(
  file.path(output_dir, "cot_vs_bottleneck_plus_cot_effects.png"),
  p_effects,
  width = 9,
  height = 5.5,
  dpi = 300
)

violin_dat <- long %>%
  group_by(pid, dim_label, condition) %>%
  summarise(rating = mean(rating), .groups = "drop") %>%
  mutate(
    outcome = factor(
      as.character(dim_label),
      levels = dim_labels,
      labels = c(
        "Thoughtful",
        "Agreement",
        "Trust",
        "Clarity",
        "Moral\ncorrectness"
      )
    ),
    system = factor(
      condition,
      levels = c("baseline", "bottleneck"),
      labels = c("Baseline (CoT)", "Bottleneck + CoT")
    ),
    outcome_number = as.numeric(outcome),
    system_shift = if_else(
      system == "Baseline (CoT)",
      -0.225,
      0.225
    ),
    x_center = outcome_number + system_shift
  )

violin_summary <- violin_dat %>%
  group_by(outcome, system) %>%
  summarise(
    x_center = first(x_center),
    mean = mean(rating),
    se = sd(rating) / sqrt(n()),
    ci_lo = mean - qt(0.975, df = n() - 1) * se,
    ci_hi = mean + qt(0.975, df = n() - 1) * se,
    .groups = "drop"
  )

make_bounded_violin_density <- function(
    values,
    lower = 1,
    upper = 7,
    grid_n = 512,
    taper_span = 0.30) {
  values <- values[is.finite(values)]
  if (length(values) < 2L) {
    stop("Each violin group must contain at least two finite ratings.")
  }

  density_bandwidth <- if (sd(values) > 0) "nrd0" else 0.25
  density_fit <- density(
    values,
    bw = density_bandwidth,
    from = lower,
    to = upper,
    n = grid_n,
    cut = 0
  )

  distance_to_edge <- pmin(
    density_fit$x - lower,
    upper - density_fit$x
  )
  taper_fraction <- pmin(
    pmax(distance_to_edge / taper_span, 0),
    1
  )
  smooth_taper <- sin(taper_fraction * pi / 2)^2
  bounded_density <- density_fit$y * smooth_taper

  if (!any(is.finite(bounded_density)) || max(bounded_density) <= 0) {
    stop("Unable to calculate a bounded violin density.")
  }

  tibble(
    rating_grid = density_fit$x,
    width_scaled = bounded_density / max(bounded_density)
  )
}

violin_density <- violin_dat %>%
  group_by(outcome, system) %>%
  group_modify(
    ~ make_bounded_violin_density(.x$rating)
  ) %>%
  ungroup() %>%
  mutate(

    outcome_number = as.numeric(outcome),
    system_shift = if_else(
      system == "Baseline (CoT)",
      -0.225,
      0.225
    ),
    x_center = outcome_number + system_shift,
    
    half_width = 0.215 * width_scaled
  )

violin_polygons <- violin_density %>%
  group_by(outcome, system) %>%
  group_modify(function(.x, .y) {
    tibble(
      x = c(
        .x$x_center - .x$half_width,
        rev(.x$x_center + .x$half_width)
      ),
      y = c(.x$rating_grid, rev(.x$rating_grid))
    )
  }) %>%
  ungroup()

p_violin <- ggplot(
  violin_dat,
  aes(
    x = x_center,
    y = rating,
    fill = system,
    group = interaction(outcome, system)
  )
) +
  geom_polygon(
    data = violin_polygons,
    aes(
      x = x,
      y = y,
      group = interaction(outcome, system),
      fill = system
    ),
    inherit.aes = FALSE,
    color = "black",
    linewidth = 0.40
  ) +
  geom_boxplot(
    width = 0.11,
    outlier.shape = NA,
    color = "black",
    linewidth = 0.45
  ) +
  geom_errorbar(
    data = violin_summary,
    aes(x = x_center, ymin = ci_lo, ymax = ci_hi, group = system),
    inherit.aes = FALSE,
    width = 0.05,
    color = "black",
    linewidth = 0.65
  ) +
  geom_point(
    data = violin_summary,
    aes(x = x_center, y = mean, group = system),
    inherit.aes = FALSE,
    shape = 23,
    size = 2.7,
    stroke = 0.65,
    fill = "white",
    color = "black"
  ) +
  scale_fill_manual(
    values = c(
      "Baseline (CoT)" = "blue",
      "Bottleneck + CoT" = "red"
    ),
    breaks = c("Baseline (CoT)", "Bottleneck + CoT")
  ) +
  scale_x_continuous(
    breaks = seq_along(levels(violin_dat$outcome)),
    labels = levels(violin_dat$outcome),
    expand = expansion(mult = c(0.04, 0.04))
  ) +
  scale_y_continuous(
    breaks = 1:7,
    limits = c(1, 7),

    expand = expansion(add = c(0.08, 0.08))
  ) +
  labs(
    x = NULL,
    y = NULL,
    fill = NULL,
    title = paste0(
      "Perceptions of Baseline (CoT) versus ",
      "Bottleneck + CoT Approaches"
    )
  ) +
  theme_minimal() +
  theme(
    text = element_text(color = "black"),
    panel.grid = element_blank(),
    axis.title.y = element_blank(),
    axis.title.x = element_blank(),
    axis.ticks.y = element_line(color = "black"),
    axis.line = element_line(color = "black"),
    plot.title.position = "plot",
    plot.title = element_text(
      size = 14,
      face = "bold",
      color = "black",
      hjust = 0.5,
      margin = margin(b = 14)
    ),
    axis.text = element_text(size = 12, color = "black"),
    legend.position = "right",
    legend.text = element_text(size = 12, color = "black"),
    legend.title = element_blank(),
    strip.text = element_text(color = "black")
  )

print(p_violin)
ggsave(
  file.path(output_dir, "cot_vs_bottleneck_plus_cot_violin.png"),
  p_violin,
  width = 10,
  height = 6.3,
  dpi = 300,
  bg = "white"
)

ggsave(
  file.path(output_dir, "cot_vs_bottleneck_plus_cot_violin.pdf"),
  p_violin,
  width = 10,
  height = 6.3,
  bg = "white"
)

cat("\nSaved results and figures to:", normalizePath(output_dir), "\n")

write.csv(desc, file.path(output_dir, "rating_descriptives.csv"), row.names = FALSE)
write.csv(data.frame(rows_read = nrow(raw), participants_retained = nrow(dat), ratings = nrow(long)),
          file.path(output_dir, "sample_counts.csv"), row.names = FALSE)
