# Alignment between human ratings and model template elements.
project_root <- local({
  configured <- getOption("bottleneck.project_root")
  source_files <- unlist(lapply(rev(sys.frames()), function(frame) frame$ofile))
  command_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  candidates <- unique(c(configured, source_files, command_file, getwd()))
  found <- NULL
  for (candidate in candidates) {
    if (!file.exists(candidate)) next
    directory <- normalizePath(if (dir.exists(candidate)) candidate else dirname(candidate), winslash = "/")
    repeat {
      if (file.exists(file.path(directory, "Cognitive_Bottlenecks.Rproj"))) {
        found <- directory
        break
      }
      parent <- dirname(directory)
      if (identical(parent, directory)) break
      directory <- parent
    }
    if (!is.null(found)) break
  }
  if (is.null(found)) stop("Open Cognitive_Bottlenecks.Rproj or run this script from the extracted project.")
  found
})
source(file.path(project_root, "R", "project_utils.R"), local = TRUE)
require_packages(c("dplyr", "tidyr", "purrr", "tibble"))
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(tibble)
})



data_dir <- project_path("data", "predictive_alignment")
output_dir <- results_dir("cognitive_alignment")

model_files <- c(
  `GPT-4o` = "gpt4o_dyadic.csv",
  `GPT-3.5` = "gpt35_dyadic.csv",
  `Llama-3-70B-Instruct` = "llama3_70b_dyadic.csv",
  `o3-mini` = "o3_mini_dyadic.csv",
  `Mixtral-8x22B` = "mixtral_8x22b_dyadic.csv",
  `Deepseek-R1` = "deepseek_r1_dyadic.csv"
)
model_files <- setNames(file.path(data_dir, unname(model_files)), names(model_files))
scenario_path <- project_path("data", "cognitive_alignment", "scenario_frames.csv")
human_path <- project_path("data", "cognitive_alignment", "cognitive_alignment_human_ratings.csv")

all_paths <- c(model_files, scenario_path, human_path)
missing_files <- all_paths[!file.exists(all_paths)]
if (length(missing_files) > 0L) {
  stop("Missing input files:\n", paste(missing_files, collapse = "\n"))
}

require_columns <- function(df, columns, label) {
  missing <- setdiff(columns, names(df))
  if (length(missing) > 0L) {
    stop(label, " is missing required column(s): ", paste(missing, collapse = ", "))
  }
}

human <- read_csv_robust(human_path, check.names = TRUE)
require_columns(human, c("att_check", "gender", "age", "race", "latino"), basename(human_path))

column_aliases <- c(
  Q1095 = "o_332_help",
  Q1101 = "o_425_harm",
  Q1147 = "o_28_moral",
  Q1161 = "o_366_moral",
  Q1164 = "o_65_harm",
  Q1172 = "o_139_help",
  Q1192 = "o_406_harm",
  Q1236 = "o_428_intent",
  n_279_int = "n_279_intent",
  n_125_mroal = "n_125_moral"
)
for (old_name in names(column_aliases)) {
  new_name <- unname(column_aliases[[old_name]])
  if (old_name %in% names(human) && !new_name %in% names(human)) {
    names(human)[names(human) == old_name] <- new_name
  }
}

human <- human[!is.na(human$att_check) & human$att_check == 1, , drop = FALSE]
if (nrow(human) != 309L) {
  warning("Expected 309 attention-check passers; found ", nrow(human), ".")
}

demographic_summary <- bind_rows(
  tibble(variable = "analysis_n", category = "all", n = nrow(human), percent = 100),
  human |>
    count(gender, name = "n") |>
    mutate(variable = "gender", category = as.character(gender), percent = 100 * n / sum(n)) |>
    select(variable, category, n, percent),
  human |>
    count(race, name = "n") |>
    mutate(variable = "race", category = as.character(race), percent = 100 * n / sum(n)) |>
    select(variable, category, n, percent),
  human |>
    count(latino, name = "n") |>
    mutate(variable = "hispanic_latino", category = as.character(latino), percent = 100 * n / sum(n)) |>
    select(variable, category, n, percent),
  tibble(
    variable = c("age_mean", "age_sd"),
    category = "years",
    n = sum(!is.na(human$age)),
    percent = c(mean(human$age, na.rm = TRUE), sd(human$age, na.rm = TRUE))
  )
)
write.csv(
  demographic_summary,
  file.path(output_dir, "survey_demographics.csv"),
  row.names = FALSE
)

aggregate_measure <- function(data, measure, output_name = measure) {
  pattern <- paste0("^[on]_[0-9]+_", measure, "$")
  columns <- grep(pattern, names(data), value = TRUE)
  if (length(columns) == 0L) stop("No survey columns found for measure: ", measure)

  out <- data |>
    select(all_of(columns)) |>
    pivot_longer(everything(), names_to = "variable", values_to = "rating") |>
    extract(
      variable,
      into = c("status_code", "id_num", "measure"),
      regex = "^([on])_([0-9]+)_(.+)$",
      convert = TRUE
    ) |>
    mutate(
      status = recode(status_code, o = "old", n = "new"),
      rating = suppressWarnings(as.numeric(rating))
    ) |>
    group_by(status, id_num) |>
    summarise(
      value = if (all(is.na(rating))) NA_real_ else mean(rating, na.rm = TRUE),
      respondent_n = sum(!is.na(rating)),
      .groups = "drop"
    ) |>
    select(status, id_num, value, respondent_n)

  names(out)[names(out) == "value"] <- output_name
  names(out)[names(out) == "respondent_n"] <- paste0(output_name, "_n")
  out
}

human_means <- list(
  aggregate_measure(human, "moral", "human_moral"),
  aggregate_measure(human, "harm", "human_harm"),
  aggregate_measure(human, "help", "human_help"),
  aggregate_measure(human, "intent", "human_intent"),
  aggregate_measure(human, "vuln", "human_vuln")
) |>
  reduce(full_join, by = c("status", "id_num"))

check_1_to_5 <- function(x, label) {
  bad <- !is.na(x) & (x < 1 | x > 5)
  if (any(bad)) {
    stop("Found ", sum(bad), " human ", label, " rating(s) outside the 1-5 survey scale.")
  }
  invisible(x)
}

scale_1_to_5_to_0_to_10 <- function(x, label = "element") {
  check_1_to_5(x, label)
  (x - 1) * 2.5
}

scale_1_to_5_to_1_to_10 <- function(x, label = "moral") {
  check_1_to_5(x, label)
  1 + (x - 1) * 2.25
}

frames_raw <- read_csv_robust(scenario_path, check.names = FALSE)

frames_raw <- frames_raw[
  ,
  !is.na(names(frames_raw)) & nzchar(trimws(names(frames_raw))),
  drop = FALSE
]

require_columns(
  frames_raw,
  c("id", "is_default_circumstance", "vulnerable_score", "intentional_score",
    "harm_score", "help_score", "moral_score"),
  basename(scenario_path)
)

# The default-frame flag is 1 for the unmodified circumstance and 0 otherwise.
if (any(!is.na(frames_raw$is_default_circumstance) &
        !frames_raw$is_default_circumstance %in% c(0, 1))) {
  stop("is_default_circumstance must contain only 0, 1, or missing values.")
}

frames_default <- frames_raw |>
  filter(is_default_circumstance == 1) |>
  mutate(
    status = sub("^.*_", "", id),
    id_num = suppressWarnings(as.integer(sub("_.*$", "", id))),
    across(
      c(vulnerable_score, intentional_score, harm_score, help_score, moral_score),
      function(x) suppressWarnings(as.numeric(x))
    )
  ) |>
  filter(!(status == "old" & id_num %in% c(35L, 139L, 349L)))

duplicate_frame_audit <- frames_default |>
  count(status, id_num, name = "rows") |>
  filter(rows > 1L)
write.csv(
  duplicate_frame_audit,
  file.path(output_dir, "duplicate_default_frame_audit.csv"),
  row.names = FALSE
)

frames <- frames_default |>
  group_by(status, id_num) |>
  summarise(
    across(
      c(vulnerable_score, intentional_score, harm_score, help_score, moral_score),
      function(x) mean(x, na.rm = TRUE)
    ),
    .groups = "drop"
  )

scenario_survey <- human_means |>
  inner_join(frames, by = c("status", "id_num")) |>
  mutate(human_moral_1_10 = scale_1_to_5_to_1_to_10(human_moral))

regression_summary <- function(df, outcome, predictor) {
  keep <- is.finite(df[[outcome]]) & is.finite(df[[predictor]])
  dat <- df[keep, , drop = FALSE]
  if (nrow(dat) < 3L || sd(dat[[outcome]]) == 0 || sd(dat[[predictor]]) == 0) {
    return(tibble(
      n = nrow(dat), r = NA_real_, b = NA_real_, se = NA_real_, t = NA_real_,
      p = NA_real_, std_beta = NA_real_, ci_lower = NA_real_, ci_upper = NA_real_
    ))
  }
  fit <- lm(reformulate(predictor, response = outcome), data = dat)
  co <- summary(fit)$coefficients[2, ]
  ci <- confint(fit)[2, ]
  tibble(
    n = nrow(dat),
    r = cor(dat[[outcome]], dat[[predictor]]),
    b = unname(co["Estimate"]),
    se = unname(co["Std. Error"]),
    t = unname(co["t value"]),
    p = unname(co["Pr(>|t|)"]),
    std_beta = cor(dat[[outcome]], dat[[predictor]]),
    ci_lower = unname(ci[1]),
    ci_upper = unname(ci[2])
  )
}

scenario_moral_alignment <- bind_rows(
  bind_cols(tibble(sample = "all"), regression_summary(scenario_survey, "moral_score", "human_moral_1_10")),
  bind_cols(tibble(sample = "old"), regression_summary(filter(scenario_survey, status == "old"), "moral_score", "human_moral_1_10")),
  bind_cols(tibble(sample = "new"), regression_summary(filter(scenario_survey, status == "new"), "moral_score", "human_moral_1_10"))
)
write.csv(
  scenario_moral_alignment,
  file.path(output_dir, "scenario_moral_alignment.csv"),
  row.names = FALSE
)

subgroup_filters <- list(
  black = human$race == 1,
  white = human$race == 2,
  asian = human$race == 4,
  latino_race_category = human$race == 5,
  hispanic_latino = human$latino == 1,
  women = human$gender == 2,
  men = human$gender == 1
)

subgroup_means <- imap(subgroup_filters, function(keep, subgroup_name) {
  aggregate_measure(human[!is.na(keep) & keep, , drop = FALSE], "moral", subgroup_name) |>
    select(status, id_num, all_of(subgroup_name))
})

subgroup_alignment <- imap_dfr(subgroup_means, function(means, subgroup_name) {
  dat <- frames |>
    inner_join(means, by = c("status", "id_num")) |>
    mutate(subgroup_moral_1_10 = scale_1_to_5_to_1_to_10(.data[[subgroup_name]], subgroup_name))
  bind_cols(
    tibble(subgroup = subgroup_name),
    regression_summary(dat, "moral_score", "subgroup_moral_1_10")
  )
}) |>
  mutate(p_holm = p.adjust(p, method = "holm"))
write.csv(
  subgroup_alignment,
  file.path(output_dir, "subgroup_moral_alignment.csv"),
  row.names = FALSE
)

subgroup_wide <- reduce(subgroup_means, full_join, by = c("status", "id_num"))
subgroup_pairs <- combn(names(subgroup_filters), 2, simplify = FALSE)
subgroup_correlations <- map_dfr(subgroup_pairs, function(pair) {
  x <- subgroup_wide[[pair[1]]]
  y <- subgroup_wide[[pair[2]]]
  keep <- is.finite(x) & is.finite(y)
  tibble(
    subgroup_1 = pair[1],
    subgroup_2 = pair[2],
    n_scenarios = sum(keep),
    r = if (sum(keep) >= 3L && sd(x[keep]) > 0 && sd(y[keep]) > 0) cor(x[keep], y[keep]) else NA_real_
  )
})
write.csv(
  subgroup_correlations,
  file.path(output_dir, "subgroup_correlations.csv"),
  row.names = FALSE
)

scenario_crosswalk <- tribble(
  ~human_id, ~model_id,
  1,370, 5,471, 23,52, 28,173, 29,644, 33,187, 40,158, 41,576,
  42,571, 58,375, 59,359, 64,290, 65,582, 69,231, 70,343, 74,85,
  78,135, 84,166, 102,410, 104,479, 105,419, 116,399, 125,80,
  132,599, 136,171, 148,43, 150,42, 151,332, 153,95, 155,469,
  168,18, 192,72, 195,542, 203,584, 207,387, 216,106, 219,307,
  225,568, 232,341, 235,308, 236,162, 253,212, 267,35,
  270,274, 272,302, 279,150, 280,143, 289,22, 290,60, 292,474,
  294,293, 301,301, 303,503, 312,185, 313,267, 320,593, 332,480,
  335,508, 340,107, 346,404, 348,556, 358,89, 359,357, 366,373,
  371,492, 389,573, 390,153, 403,435, 406,82, 416,498, 417,208,
  418,248, 422,118, 425,465, 428,381, 430,344, 435,94, 436,255,
  438,567, 446,607, 450,487, 455,637, 462,422
)
stopifnot(nrow(scenario_crosswalk) == 83L)
stopifnot(!anyDuplicated(scenario_crosswalk$human_id))
stopifnot(!anyDuplicated(scenario_crosswalk$model_id))

human_old <- human_means |>
  filter(status == "old") |>
  transmute(
    human_id = id_num,
    human_moral_survey = human_moral,
    person_harm = scale_1_to_5_to_0_to_10(human_harm, "harm"),
    person_help = scale_1_to_5_to_0_to_10(human_help, "help"),
    person_intent = scale_1_to_5_to_0_to_10(human_intent, "intent"),
    person_vuln = scale_1_to_5_to_0_to_10(human_vuln, "vuln")
  ) |>
  right_join(scenario_crosswalk, by = "human_id")

if (nrow(human_old) != 83L) stop("The verified scenario crosswalk did not produce 83 survey rows.")

load_aligned_model <- function(path, model_name) {
  df <- read_csv_robust(path, check.names = FALSE)
  require_columns(
    df,
    c("id", "dataset", "human_score", "moral_score", "vulnerable_score",
      "intentional_score", "harm_score", "help_score"),
    basename(path)
  )
  df <- df |>
    mutate(
      model_id = suppressWarnings(as.integer(id)),
      across(
        c(human_score, moral_score, vulnerable_score, intentional_score,
          harm_score, help_score),
        function(x) suppressWarnings(as.numeric(x))
      )
    )
  if (anyDuplicated(df$model_id)) stop(basename(path), " contains duplicate IDs.")
  if (!all(scenario_crosswalk$model_id %in% df$model_id)) {
    stop(model_name, " is missing a crosswalk scenario ID.")
  }

  out <- scenario_crosswalk |>
    left_join(
      df |>
        select(
          model_id, dataset,
          person_moral = human_score, gpt_moral = moral_score,
          gpt_vuln = vulnerable_score, gpt_intent = intentional_score,
          gpt_harm = harm_score, gpt_help = help_score
        ),
      by = "model_id"
    ) |>
    left_join(human_old, by = c("human_id", "model_id")) |>
    mutate(Model = model_name)

  out
}

aligned_models <- imap(model_files, load_aligned_model)

reference_model <- aligned_models[["GPT-4o"]]
crosswalk_audit <- reference_model |>
  select(human_id, model_id, dataset)
write.csv(
  crosswalk_audit,
  file.path(output_dir, "scenario_crosswalk_audit.csv"),
  row.names = FALSE
)

elements <- c("harm", "help", "intent", "vuln")
element_stats <- function(dat, element) {
  predictor <- paste0("gpt_", element)
  outcome <- paste0("person_", element)
  bind_cols(
    tibble(Element = element),
    regression_summary(dat, outcome, predictor)
  )
}

alignment_stats <- imap_dfr(aligned_models, function(dat, model_name) {
  map_dfr(elements, function(element) element_stats(dat, element)) |>
    mutate(Model = model_name, .before = Element)
}) |>
  group_by(Element) |>
  mutate(p_holm = p.adjust(p, method = "holm")) |>
  ungroup()
write.csv(
  alignment_stats,
  file.path(output_dir, "alignment_stats_table.csv"),
  row.names = FALSE
)

model_r2 <- imap_dfr(aligned_models, function(dat, model_name) {
  fit <- lm(
    gpt_moral ~ gpt_help + gpt_harm +
      gpt_intent * gpt_harm +
      gpt_vuln * gpt_harm,
    data = dat
  )
  tibble(
    Model = model_name,
    n = nobs(fit),
    r_squared = summary(fit)$r.squared,
    adjusted_r_squared = summary(fit)$adj.r.squared
  )
})
write.csv(
  model_r2,
  file.path(output_dir, "model_r2_table.csv"),
  row.names = FALSE
)

human_r2_fit <- function(dat) {
  lm(
    human_moral ~ human_help + human_harm +
      human_intent * human_harm +
      human_vuln * human_harm,
    data = dat
  )
}
human_r2 <- bind_rows(
  {
    fit <- human_r2_fit(human_means)
    tibble(sample = "all_survey_scenarios", n = nobs(fit),
           r_squared = summary(fit)$r.squared,
           adjusted_r_squared = summary(fit)$adj.r.squared)
  },
  {
    fit <- human_r2_fit(filter(human_means, status == "old"))
    tibble(sample = "old_survey_scenarios", n = nobs(fit),
           r_squared = summary(fit)$r.squared,
           adjusted_r_squared = summary(fit)$adj.r.squared)
  },
  {
    fit <- human_r2_fit(
      human_means |>
        filter(status == "old") |>
        semi_join(scenario_crosswalk, by = c("id_num" = "human_id"))
    )
    tibble(sample = "crosswalk_83_scenarios", n = nobs(fit),
           r_squared = summary(fit)$r.squared,
           adjusted_r_squared = summary(fit)$adj.r.squared)
  }
)
write.csv(
  human_r2,
  file.path(output_dir, "human_r2_table.csv"),
  row.names = FALSE
)

descriptive_stats <- imap_dfr(aligned_models, function(dat, model_name) {
  tibble(
    Model = model_name,
    n = nrow(dat),
    mean_human_vuln = mean(dat$person_vuln, na.rm = TRUE),
    mean_gpt_vuln = mean(dat$gpt_vuln, na.rm = TRUE),
    range_human_vuln = diff(range(dat$person_vuln, na.rm = TRUE)),
    range_gpt_vuln = diff(range(dat$gpt_vuln, na.rm = TRUE)),
    mean_human_intent = mean(dat$person_intent, na.rm = TRUE),
    mean_gpt_intent = mean(dat$gpt_intent, na.rm = TRUE),
    range_human_intent = diff(range(dat$person_intent, na.rm = TRUE)),
    range_gpt_intent = diff(range(dat$gpt_intent, na.rm = TRUE))
  )
})
write.csv(
  descriptive_stats,
  file.path(output_dir, "descriptive_stats_vuln_intent.csv"),
  row.names = FALSE
)

sample_counts <- imap_dfr(aligned_models, function(dat, model_name) {
  tibble(
    Model = model_name,
    crosswalk_n = nrow(dat),
    complete_harm_n = sum(complete.cases(dat$person_harm, dat$gpt_harm)),
    complete_help_n = sum(complete.cases(dat$person_help, dat$gpt_help)),
    complete_intent_n = sum(complete.cases(dat$person_intent, dat$gpt_intent)),
    complete_vuln_n = sum(complete.cases(dat$person_vuln, dat$gpt_vuln))
  )
})
write.csv(
  sample_counts,
  file.path(output_dir, "analysis_sample_counts.csv"),
  row.names = FALSE
)

message(
  "Construct-alignment analysis complete. Survey N = ", nrow(human),
  "; verified scenario crosswalk N = ", nrow(scenario_crosswalk),
  ". Results written to: ", normalizePath(output_dir)
)
