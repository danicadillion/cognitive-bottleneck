# Supervised ridge predictive alignment.
project_root <- local({
  configured <- getOption("bottleneck.project_root")
  source_files <- unlist(lapply(rev(sys.frames()), function(frame) frame$ofile))
  command_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  candidates <- unique(c(configured, source_files, command_file, getwd()))
  found <- NULL
  for (candidate in candidates) {
    if (!file.exists(candidate)) next
    directory <- normalizePath(if (dir.exists(candidate)) candidate else dirname(candidate), winslash = "/")
    repeat {
      if (file.exists(file.path(directory, "Cognitive_Bottlenecks.Rproj"))) {
        found <- directory
        break
      }
      parent <- dirname(directory)
      if (identical(parent, directory)) break
      directory <- parent
    }
    if (!is.null(found)) break
  }
  if (is.null(found)) stop("Open Cognitive_Bottlenecks.Rproj or run this script from the extracted project.")
  found
})
source(file.path(project_root, "R", "project_utils.R"), local = TRUE)
require_packages(c("dplyr", "tidyr", "purrr", "tibble"))
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(tibble)
})



data_dir <- project_path("data", "predictive_alignment")
output_dir <- results_dir("regression")

score_column <- "regression_score"
analysis_suffix <- "reg"

model_order <- c(
  "GPT-4o", "GPT-3.5", "Llama-3-70B-Instruct",
  "o3-mini", "Mixtral-8x22B", "Deepseek-R1"
)

file_map <- list(
  dyadic = c(
    `GPT-4o` = "gpt4o_dyadic.csv",
    `GPT-3.5` = "gpt35_dyadic.csv",
    `Llama-3-70B-Instruct` = "llama3_70b_dyadic.csv",
    `o3-mini` = "o3_mini_dyadic.csv",
    `Mixtral-8x22B` = "mixtral_8x22b_dyadic.csv",
    `Deepseek-R1` = "deepseek_r1_dyadic.csv"
  ),
  mft = c(
    `GPT-4o` = "gpt4o_mft.csv",
    `GPT-3.5` = "gpt35_mft.csv",
    `Llama-3-70B-Instruct` = "llama3_70b_mft.csv",
    `o3-mini` = "o3_mini_mft.csv",
    `Mixtral-8x22B` = "mixtral_8x22b_mft.csv",
    `Deepseek-R1` = "deepseek_r1_mft.csv"
  ),
  cooperation = c(
    `GPT-4o` = "gpt4o_morality_as_cooperation.csv",
    `GPT-3.5` = "gpt35_morality_as_cooperation.csv",
    `Llama-3-70B-Instruct` = "llama3_70b_morality_as_cooperation.csv",
    `o3-mini` = "o3_mini_morality_as_cooperation.csv",
    `Mixtral-8x22B` = "mixtral_8x22b_morality_as_cooperation.csv",
    `Deepseek-R1` = "deepseek_r1_morality_as_cooperation.csv"
  ),
  virtue = c(
    `GPT-4o` = "gpt4o_virtue_ethics.csv",
    `GPT-3.5` = "gpt35_virtue_ethics.csv",
    `Llama-3-70B-Instruct` = "llama3_70b_virtue_ethics.csv",
    `o3-mini` = "o3_mini_virtue_ethics.csv",
    `Mixtral-8x22B` = "mixtral_8x22b_virtue_ethics.csv",
    `Deepseek-R1` = "deepseek_r1_virtue_ethics.csv"
  ),
  utilitarianism = c(
    `GPT-4o` = "gpt4o_utilitarianism.csv",
    `GPT-3.5` = "gpt35_utilitarianism.csv",
    `Llama-3-70B-Instruct` = "llama3_70b_utilitarianism.csv",
    `o3-mini` = "o3_mini_utilitarianism.csv",
    `Mixtral-8x22B` = "mixtral_8x22b_utilitarianism.csv",
    `Deepseek-R1` = "deepseek_r1_utilitarianism.csv"
  ),
  deontology = c(
    `GPT-4o` = "gpt4o_deontology.csv",
    `GPT-3.5` = "gpt35_deontology.csv",
    `Llama-3-70B-Instruct` = "llama3_70b_deontology.csv",
    `o3-mini` = "o3_mini_deontology.csv",
    `Mixtral-8x22B` = "mixtral_8x22b_deontology.csv",
    `Deepseek-R1` = "deepseek_r1_deontology.csv"
  ),
  ete = c(
    `GPT-4o` = "gpt4o_baseline.csv",
    `GPT-3.5` = "gpt35_baseline.csv",
    `Llama-3-70B-Instruct` = "llama3_70b_baseline.csv",
    `o3-mini` = "o3_mini_baseline.csv",
    `Mixtral-8x22B` = "mixtral_8x22b_baseline.csv",
    `Deepseek-R1` = "deepseek_r1_baseline.csv"
  )
)

file_map <- map(file_map, function(x) file.path(data_dir, unname(x)) |>
  setNames(names(x)))

all_paths <- unlist(file_map, use.names = FALSE)
missing_files <- all_paths[!file.exists(all_paths)]
if (length(missing_files) > 0L) {
  stop("Missing input files:\n", paste(missing_files, collapse = "\n"))
}

require_columns <- function(df, columns, path) {
  missing <- setdiff(columns, names(df))
  if (length(missing) > 0L) {
    stop(
      basename(path), " is missing required column(s): ",
      paste(missing, collapse = ", ")
    )
  }
}

load_prediction_file <- function(path, prompt_type, gpt_model) {
  df <- read_csv_robust(path)
  require_columns(df, c("id", "dataset", "human_score"), path)

  if (prompt_type == "ete") {
    require_columns(df, "moral_score", path)
    df$score <- suppressWarnings(as.numeric(df$moral_score))
  } else {
    require_columns(df, c("split", score_column), path)
    invalid_splits <- setdiff(unique(na.omit(df$split)), c("train", "test"))
    if (length(invalid_splits) > 0L) {
      stop(
        basename(path), " contains invalid split value(s): ",
        paste(invalid_splits, collapse = ", ")
      )
    }
    df <- df[df$split == "test", , drop = FALSE]
    df$score <- suppressWarnings(as.numeric(df[[score_column]]))
    if (anyNA(df$score)) {
      stop(
        basename(path), " has missing/non-numeric ", score_column,
        " values among test rows."
      )
    }
  }

  df$person_moral <- suppressWarnings(as.numeric(df$human_score))
  df$scenario_id <- paste(df$dataset, df$id, sep = "::")

  if (anyDuplicated(df$scenario_id)) {
    stop(basename(path), " contains duplicate dataset/id keys.")
  }
  if (anyNA(df$score) || anyNA(df$person_moral)) {
    stop(basename(path), " has missing/non-numeric analysis scores.")
  }

  tibble(
    scenario_id = df$scenario_id,
    dataset = df$dataset,
    id = df$id,
    person_moral = df$person_moral,
    score = df$score,
    prompt_type = prompt_type,
    gpt_model = gpt_model,
    source_file = basename(path)
  )
}

theory_names <- setdiff(names(file_map), "ete")
theory_frames <- list()

for (prompt_type in theory_names) {
  for (gpt_model in names(file_map[[prompt_type]])) {
    key <- paste(prompt_type, gpt_model, sep = "::")
    theory_frames[[key]] <- load_prediction_file(
      file_map[[prompt_type]][[gpt_model]], prompt_type, gpt_model
    )
  }
}

common_test_ids <- Reduce(
  intersect,
  lapply(theory_frames, function(x) x$scenario_id)
)
if (length(common_test_ids) < 2L) {
  stop("No usable common held-out scenario set was found.")
}

ete_frames <- list()
for (gpt_model in names(file_map$ete)) {
  ete_frames[[gpt_model]] <- load_prediction_file(
    file_map$ete[[gpt_model]], "ete", gpt_model
  )
  missing_baseline <- setdiff(common_test_ids, ete_frames[[gpt_model]]$scenario_id)
  if (length(missing_baseline) > 0L) {
    stop(
      "The ETE baseline for ", gpt_model, " is missing ",
      length(missing_baseline), " common test scenario(s)."
    )
  }
}

available_counts <- bind_rows(
  imap_dfr(theory_frames, function(x, key) {
    tibble(
      prompt_type = x$prompt_type[1],
      gpt_model = x$gpt_model[1],
      available_score_n = nrow(x),
      retained_common_n = sum(x$scenario_id %in% common_test_ids),
      source_file = x$source_file[1]
    )
  }),
  imap_dfr(ete_frames, function(x, key) {
    tibble(
      prompt_type = "ete",
      gpt_model = x$gpt_model[1],
      available_score_n = nrow(x),
      retained_common_n = sum(x$scenario_id %in% common_test_ids),
      source_file = x$source_file[1]
    )
  })
) |>
  mutate(
    prompt_type = factor(prompt_type, levels = c(theory_names, "ete")),
    gpt_model = factor(gpt_model, levels = model_order)
  ) |>
  arrange(prompt_type, gpt_model) |>
  mutate(across(c(prompt_type, gpt_model), as.character))

all_data <- bind_rows(c(theory_frames, ete_frames)) |>
  filter(scenario_id %in% common_test_ids) |>
  mutate(
    prompt_type = factor(prompt_type, levels = c(theory_names, "ete")),
    gpt_model = factor(gpt_model, levels = model_order),
    absolute_diff = abs(score - person_moral)
  )

human_score_conflicts <- all_data |>
  group_by(scenario_id) |>
  summarise(score_range = max(person_moral) - min(person_moral), .groups = "drop") |>
  filter(score_range > 1e-8)
if (nrow(human_score_conflicts) > 0L) {
  stop("Human scores disagree across input files for at least one scenario ID.")
}

expected_group_n <- length(common_test_ids)
group_check <- all_data |>
  count(prompt_type, gpt_model, name = "n")
if (any(group_check$n != expected_group_n)) {
  stop("At least one prompt/model group is not represented on the common set.")
}

write.csv(
  available_counts,
  file.path(output_dir, paste0("analysis_sample_counts_", analysis_suffix, ".csv")),
  row.names = FALSE
)

prediction_range_audit <- all_data |>
  group_by(prompt_type, gpt_model) |>
  summarise(
    n = n(),
    minimum = min(score),
    maximum = max(score),
    below_scale_n = sum(score < -4),
    above_scale_n = sum(score > 4),
    .groups = "drop"
  )
write.csv(
  prediction_range_audit,
  file.path(output_dir, paste0("prediction_range_audit_", analysis_suffix, ".csv")),
  row.names = FALSE
)

safe_cor <- function(x, y) {
  if (length(x) < 3L || sd(x) == 0 || sd(y) == 0) return(NA_real_)
  cor(x, y)
}

ols_stats <- function(df, outcome, predictor) {
  keep <- is.finite(df[[outcome]]) & is.finite(df[[predictor]])
  dat <- df[keep, , drop = FALSE]
  if (nrow(dat) < 3L || sd(dat[[predictor]]) == 0) {
    return(tibble(
      n = nrow(dat), b = NA_real_, se = NA_real_, t = NA_real_,
      p_raw = NA_real_, std_beta = NA_real_, ci_lower = NA_real_,
      ci_upper = NA_real_
    ))
  }
  fit <- lm(reformulate(predictor, response = outcome), data = dat)
  co <- summary(fit)$coefficients[2, ]
  ci <- confint(fit)[2, ]
  tibble(
    n = nrow(dat),
    b = unname(co["Estimate"]),
    se = unname(co["Std. Error"]),
    t = unname(co["t value"]),
    p_raw = unname(co["Pr(>|t|)"]),
    std_beta = safe_cor(dat[[predictor]], dat[[outcome]]),
    ci_lower = unname(ci[1]),
    ci_upper = unname(ci[2])
  )
}

cluster_term_stats <- function(fit, cluster, term) {
  x <- model.matrix(fit)
  u <- residuals(fit)
  cluster <- as.factor(cluster)
  n <- nrow(x)
  k <- ncol(x)
  g <- nlevels(cluster)
  if (length(cluster) != n || g < 2L || n <= k) {
    stop("Invalid dimensions for scenario-clustered standard errors.")
  }
  bread <- solve(crossprod(x))
  score_by_cluster <- rowsum(x * as.numeric(u), cluster, reorder = FALSE)
  meat <- crossprod(score_by_cluster)
  adjustment <- (g / (g - 1)) * ((n - 1) / (n - k))
  vcov_cluster <- adjustment * bread %*% meat %*% bread
  estimate <- unname(coef(fit)[term])
  se <- sqrt(unname(vcov_cluster[term, term]))
  t_value <- estimate / se
  df <- g - 1
  p_value <- 2 * pt(abs(t_value), df = df, lower.tail = FALSE)
  critical <- qt(.975, df = df)
  tibble(
    b = estimate,
    se = se,
    t = t_value,
    p_raw = p_value,
    ci_lower = estimate - critical * se,
    ci_upper = estimate + critical * se
  )
}

emd_equal_n <- function(x, y) {
  stopifnot(length(x) == length(y))
  mean(abs(sort(x) - sort(y)))
}

table1a <- all_data |>
  group_by(prompt_type, gpt_model) |>
  summarise(n = n(), r = safe_cor(score, person_moral), .groups = "drop")
write.csv(
  table1a,
  file.path(output_dir, paste0("table1a_correlations_", analysis_suffix, ".csv")),
  row.names = FALSE
)

table1b <- all_data |>
  group_by(prompt_type, gpt_model) |>
  group_modify(function(.x, .y) ols_stats(.x, "person_moral", "score")) |>
  ungroup() |>
  mutate(p_holm = p.adjust(p_raw, method = "holm"))
write.csv(
  table1b,
  file.path(output_dir, paste0("table1b_regressions_", analysis_suffix, ".csv")),
  row.names = FALSE
)

paired_prompt_data <- function(model_data, theory) {
  sub <- model_data |>
    filter(as.character(prompt_type) %in% c("ete", theory)) |>
    mutate(prompt_factor = relevel(factor(as.character(prompt_type)), ref = "ete")) |>
    arrange(scenario_id, prompt_factor)
  counts <- table(sub$scenario_id)
  if (length(counts) != expected_group_n || any(counts != 2L)) {
    stop("Pairing failed for ", unique(as.character(model_data$gpt_model)), "/", theory)
  }
  sub
}

table2 <- map_dfr(model_order, function(model_name) {
  model_data <- all_data |>
    filter(as.character(gpt_model) == model_name)
  map_dfr(theory_names, function(theory) {
    sub <- paired_prompt_data(model_data, theory)
    fit <- lm(person_moral ~ score * prompt_factor, data = sub)
    term <- grep("^score:prompt_factor", names(coef(fit)), value = TRUE)
    if (length(term) != 1L) stop("Could not identify the slope interaction term.")
    out <- cluster_term_stats(fit, sub$scenario_id, term)

    std_dat <- sub |>
      mutate(
        person_z = as.numeric(scale(person_moral)),
        score_z = as.numeric(scale(score))
      )
    std_fit <- lm(person_z ~ score_z * prompt_factor, data = std_dat)
    std_term <- grep("^score_z:prompt_factor", names(coef(std_fit)), value = TRUE)

    bind_cols(
      tibble(
        theory = theory,
        gpt_model = model_name,
        n_pairs = expected_group_n,
        r_ete = safe_cor(sub$score[sub$prompt_factor == "ete"],
                         sub$person_moral[sub$prompt_factor == "ete"]),
        r_theory = safe_cor(sub$score[sub$prompt_factor != "ete"],
                            sub$person_moral[sub$prompt_factor != "ete"]),
        std_beta_interaction = unname(coef(std_fit)[std_term])
      ),
      out
    )
  })
}) |>
  mutate(
    p_holm = p.adjust(p_raw, method = "holm"),
    comparison = case_when(
      p_holm < .05 & b > 0 ~ "theory slope higher",
      p_holm < .05 & b < 0 ~ "ETE slope higher",
      TRUE ~ "no Holm-adjusted slope difference"
    )
  )
write.csv(
  table2,
  file.path(output_dir, paste0("table2_slope_interactions_", analysis_suffix, ".csv")),
  row.names = FALSE
)

table3 <- all_data |>
  group_by(prompt_type, gpt_model) |>
  summarise(n = n(), MSE = mean((score - person_moral)^2), .groups = "drop")
write.csv(
  table3,
  file.path(output_dir, paste0("table3_mse_", analysis_suffix, ".csv")),
  row.names = FALSE
)

table4 <- all_data |>
  group_by(prompt_type, gpt_model) |>
  summarise(n = n(), EMD = emd_equal_n(score, person_moral), .groups = "drop")
write.csv(
  table4,
  file.path(output_dir, paste0("table4_emd_", analysis_suffix, ".csv")),
  row.names = FALSE
)

table5a <- all_data |>
  group_by(prompt_type, gpt_model) |>
  group_modify(function(.x, .y) ols_stats(.x, "absolute_diff", "person_moral")) |>
  ungroup() |>
  mutate(p_holm = p.adjust(p_raw, method = "holm"))
write.csv(
  table5a,
  file.path(output_dir, paste0("table5a_absdiff_slopes_", analysis_suffix, ".csv")),
  row.names = FALSE
)

table5b <- map_dfr(model_order, function(model_name) {
  model_data <- all_data |>
    filter(as.character(gpt_model) == model_name)
  map_dfr(theory_names, function(theory) {
    sub <- paired_prompt_data(model_data, theory)
    fit <- lm(absolute_diff ~ person_moral * prompt_factor, data = sub)
    term <- grep("^person_moral:prompt_factor", names(coef(fit)), value = TRUE)
    if (length(term) != 1L) stop("Could not identify the valence interaction term.")
    bind_cols(
      tibble(theory = theory, gpt_model = model_name, n_pairs = expected_group_n),
      cluster_term_stats(fit, sub$scenario_id, term)
    )
  })
}) |>
  mutate(p_holm = p.adjust(p_raw, method = "holm"))
write.csv(
  table5b,
  file.path(output_dir, paste0("table5b_absdiff_interactions_", analysis_suffix, ".csv")),
  row.names = FALSE
)

table6 <- map_dfr(model_order, function(model_name) {
  model_data <- all_data |>
    filter(as.character(gpt_model) == model_name)
  map_dfr(theory_names, function(theory) {
    sub <- paired_prompt_data(model_data, theory) |>
      select(scenario_id, prompt_factor, absolute_diff) |>
      pivot_wider(names_from = prompt_factor, values_from = absolute_diff)
    differences <- sub[[theory]] - sub$ete
    test <- t.test(differences, mu = 0)
    tibble(
      theory = theory,
      gpt_model = model_name,
      n_pairs = length(differences),
      mean_error_difference = mean(differences),
      se = sd(differences) / sqrt(length(differences)),
      t = unname(test$statistic),
      p_raw = test$p.value,
      ci_lower = test$conf.int[1],
      ci_upper = test$conf.int[2],
      std_effect_dz = mean(differences) / sd(differences)
    )
  })
}) |>
  mutate(
    p_holm = p.adjust(p_raw, method = "holm"),
    comparison = case_when(
      p_holm < .05 & mean_error_difference < 0 ~ "theory lower error",
      p_holm < .05 & mean_error_difference > 0 ~ "ETE lower error",
      TRUE ~ "no Holm-adjusted error difference"
    )
  )
write.csv(
  table6,
  file.path(output_dir, paste0("table6_paired_absdiff_", analysis_suffix, ".csv")),
  row.names = FALSE
)

message(
  "Analysis complete. Common held-out N = ", expected_group_n,
  ". Results written to: ", normalizePath(output_dir)
)
