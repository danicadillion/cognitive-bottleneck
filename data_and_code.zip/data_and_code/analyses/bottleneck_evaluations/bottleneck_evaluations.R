# Perceived morality, trust, and transparency of AI systems.
project_root <- local({
  configured <- getOption("bottleneck.project_root")
  source_files <- unlist(lapply(rev(sys.frames()), function(frame) frame$ofile))
  command_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  candidates <- unique(c(configured, source_files, command_file, getwd()))
  found <- NULL
  for (candidate in candidates) {
    if (!file.exists(candidate)) next
    directory <- normalizePath(if (dir.exists(candidate)) candidate else dirname(candidate), winslash = "/")
    repeat {
      if (file.exists(file.path(directory, "Cognitive_Bottlenecks.Rproj"))) {
        found <- directory
        break
      }
      parent <- dirname(directory)
      if (identical(parent, directory)) break
      directory <- parent
    }
    if (!is.null(found)) break
  }
  if (is.null(found)) stop("Open Cognitive_Bottlenecks.Rproj or run this script from the extracted project.")
  found
})
source(file.path(project_root, "R", "project_utils.R"), local = TRUE)

require_packages(c("dplyr", "tidyr", "ggplot2", "effsize", "lavaan"))
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(effsize)
  library(lavaan)
})

output_dir <- results_dir("bottleneck_evaluations")
data_path <- project_path("data", "bottleneck_evaluations", "Bottleneck_Evaluations.csv")
if (!file.exists(data_path)) stop("Missing perceptions input: ", data_path)
d <- read.csv(data_path, check.names = FALSE, stringsAsFactors = FALSE)
item_suffixes <- c("moral1", "moral2", "moral3", "trust", "use", "society",
                   "transparent", "clear", "understand")
item_columns <- c(paste0("dyadic_", item_suffixes), paste0("baseline_", item_suffixes))
required_columns <- c("manip_check", "age", "gender", "race", item_columns)
missing_columns <- setdiff(required_columns, names(d))
if (length(missing_columns)) stop("Missing columns: ", paste(missing_columns, collapse = ", "))
for (name in c("manip_check", "age", item_columns)) {
  d[[name]] <- suppressWarnings(as.numeric(d[[name]]))
} 

d <- d %>%
  filter(manip_check == 1)

rescaled_items <- c("dyadic_moral1", "dyadic_transparent")
for (name in item_columns) {
  upper <- if (name %in% rescaled_items) 8 else 7
  value <- d[[name]]
  if (any(!is.na(value) & (!is.finite(value) | value < 1 | value > upper | value != floor(value)))) {
    stop("Unexpected raw coding for ", name, "; expected integers 1-", upper, ". expected integers 1–N.")
  }
}
if (nrow(d) != 239L) warning("Expected 239 retained participants; found ", nrow(d))
d <- d %>%
  mutate(
    dyadic_moral1 = (dyadic_moral1 - 1) * 6 / 7 + 1,
    dyadic_transparent = (dyadic_transparent - 1) * 6 / 7 + 1
  )

total_participants <- nrow(d)
cat("Total participants:", total_participants, "\n\n")

mean_age <- mean(d$age, na.rm = TRUE)
sd_age   <- sd(d$age, na.rm = TRUE)
cat("Age Summary:\n")
cat("Mage =", round(mean_age, 2), ", Sdage =", round(sd_age, 2), "\n\n")

gender_counts <- d %>%
  group_by(gender) %>%
  summarise(Count = n())

cat("Gender Breakdown:\n")
print(gender_counts)
cat("\n")

ethnicity_stats <- d %>%
  group_by(race) %>%
  summarise(Count = n()) %>%
  mutate(Percentage = round(100 * Count / sum(Count), 1))

cat("Ethnicity Breakdown (Percentages):\n")
print(ethnicity_stats)

d <- d %>%
  mutate(dyadic_moral = rowMeans(dplyr::select(., dyadic_moral1, dyadic_moral2, dyadic_moral3), na.rm = TRUE))

d <- d %>%
  mutate(baseline_moral = rowMeans(dplyr::select(., baseline_moral1, baseline_moral2, baseline_moral3), na.rm = TRUE))

t_test_result <- t.test(d$dyadic_moral, d$baseline_moral, 
                        paired = FALSE)
range(d$dyadic_moral1, na.rm = T)

print(t_test_result)

group1 <- d$dyadic_moral 
group2 <- d$baseline_moral 

group1 <- na.omit(group1)
group2 <- na.omit(group2)

cohen.d(group1, group2, hedges.correction = FALSE)

d <- d %>%
  mutate(
    dyadic_composite   = rowMeans(dplyr::select(., dyadic_trust, dyadic_use, dyadic_society), na.rm = TRUE),
    baseline_composite = rowMeans(dplyr::select(., baseline_trust, baseline_use, baseline_society), na.rm = TRUE)
  )

t_test_result <- t.test(d$dyadic_composite, d$baseline_composite, paired = FALSE)
print(t_test_result)

group1 <- d$dyadic_composite 
group2 <- d$baseline_composite 

group1 <- na.omit(group1)
group2 <- na.omit(group2)

cohen.d(group1, group2, hedges.correction = FALSE)

d <- d %>%
  mutate(dyadic_transparent_combined = rowMeans(dplyr::select(., dyadic_transparent, dyadic_clear, dyadic_understand), na.rm = TRUE))

d <- d %>%
  mutate(baseline_transparent_combined = rowMeans(dplyr::select(., baseline_transparent, baseline_clear, baseline_understand), na.rm = TRUE))

t_test_result <- t.test(d$dyadic_transparent_combined, d$baseline_transparent_combined, 
                        paired = FALSE)

print(t_test_result)

group1 <- d$dyadic_transparent_combined 
group2 <- d$baseline_transparent_combined 

group1 <- na.omit(group1)
group2 <- na.omit(group2)

cohen.d(group1, group2, hedges.correction = FALSE)

moral_stats <- d %>%
  summarise(
    mean_dyadic_moral   = mean(dyadic_moral, na.rm = TRUE),
    sd_dyadic_moral     = sd(dyadic_moral, na.rm = TRUE),
    mean_baseline_moral = mean(baseline_moral, na.rm = TRUE),
    sd_baseline_moral   = sd(baseline_moral, na.rm = TRUE)
  )
cat("Moral Measures:\n")
print(moral_stats)

trust_stats <- d %>%
  summarise(
    mean_dyadic_composite   = mean(dyadic_composite, na.rm = TRUE),
    sd_dyadic_composite     = sd(dyadic_composite, na.rm = TRUE),
    mean_baseline_composite = mean(baseline_composite, na.rm = TRUE),
    sd_baseline_composite   = sd(baseline_composite, na.rm = TRUE)
  )
cat("\nTrust Composite Measures:\n")
print(trust_stats)

transparent_stats <- d %>%
  summarise(
    mean_dyadic_transparent   = mean(dyadic_transparent_combined, na.rm = TRUE),
    sd_dyadic_transparent     = sd(dyadic_transparent_combined, na.rm = TRUE),
    mean_baseline_transparent = mean(baseline_transparent_combined, na.rm = TRUE),
    sd_baseline_transparent   = sd(baseline_transparent_combined, na.rm = TRUE)
  )
cat("\nTransparent Composite Measures:\n")
print(transparent_stats)

long_data <- d %>%
  pivot_longer(
    cols = c(
      dyadic_moral, baseline_moral,
      dyadic_composite, baseline_composite,
      dyadic_transparent_combined, baseline_transparent_combined
    ),
    names_to = c("Condition", "Variable"),
    names_pattern = "(dyadic|baseline)_(.*)",
    values_to = "Value"
  )

summary_data <- long_data %>%
  group_by(Condition, Variable) %>%
  summarize(
    Mean = mean(Value, na.rm = TRUE),
    SE = sd(Value, na.rm = TRUE) / sqrt(sum(!is.na(Value))),
    .groups = "drop"
  )

long_data <- long_data %>%
  mutate(Variable = recode(Variable,
                           "composite" = "Trust",
                           "moral" = "Morality",
                           "transparent_combined" = "Transparency"))

perceptions_plot <- ggplot(dplyr::filter(long_data, is.finite(Value)), aes(x = Variable, y = Value, fill = Condition)) +
  
  geom_violin(position = position_dodge(width = 0.9), color = "black") +
  
  geom_boxplot(width = 0.1, 
               position = position_dodge(width = 0.9), 
               outlier.shape = NA, 
               color = "black") +
  labs(
    title = "Perceptions of Bottleneck versus Baseline Approaches"
  ) +
  theme_minimal() +
  theme(
    panel.grid = element_blank(), 
    axis.title.y = element_blank(), 
    axis.title.x = element_blank(), 
    axis.ticks.y = element_line(color = "black"), 
    axis.line = element_line(color = "black"), 
    plot.title = element_text(size = 14, face = "bold", color = "black"), 
    axis.text = element_text(size = 12, color = "black"), 
    legend.text = element_text(size = 12, color = "black"), 
    legend.title = element_blank() 
  ) +
  scale_y_continuous(limits = c(1, 7), breaks = 1:7) + 
  scale_fill_manual(values = c("dyadic" = "red", "baseline" = "blue"),
                    labels = c("baseline" = "Baseline", "dyadic" = "Bottleneck"))

cfa.1a <-'#factor loadings
transparent =~  baseline_clear + baseline_understand + baseline_transparent
moral =~ baseline_moral1 + baseline_moral2 + baseline_moral3 
trust =~ baseline_trust + baseline_use + baseline_society

 #covariance
 '

fit.1a <- cfa(cfa.1a, data=d, meanstructure=TRUE, std.lv=TRUE)
summary(fit.1a, fit.measures=TRUE, standardized=TRUE, rsquare=TRUE)

modindices(fit.1a, sort.=TRUE)

d <- d %>%
  mutate(
    
    clear_new       = coalesce(baseline_clear,       dyadic_clear),
    understand_new  = coalesce(baseline_understand,  dyadic_understand),
    transparent_new = coalesce(baseline_transparent, dyadic_transparent),

    moral1_new = coalesce(baseline_moral1, dyadic_moral1),
    moral2_new = coalesce(baseline_moral2, dyadic_moral2),
    moral3_new = coalesce(baseline_moral3, dyadic_moral3),

    trust_new   = coalesce(baseline_trust,   dyadic_trust),
    use_new     = coalesce(baseline_use,     dyadic_use),
    society_new = coalesce(baseline_society, dyadic_society)
  )

cfa.1a <- '
  # Factor loadings
  transparent =~ clear_new + understand_new + transparent_new
  moral       =~ moral1_new + moral2_new + moral3_new
  trust       =~ trust_new + use_new + society_new

  
'

fit.1a <- cfa(cfa.1a, data = d, meanstructure = TRUE, std.lv = TRUE)
summary(fit.1a, fit.measures = TRUE, standardized = TRUE, rsquare = TRUE)
modindices(fit.1a, sort.= TRUE)

ggsave(file.path(output_dir, "bottleneck_evaluations.png"), perceptions_plot,
       width = 8, height = 5, units = "in", dpi = 300, bg = "white")
composites <- list(Morality = c("dyadic_moral", "baseline_moral"),
                   Trust = c("dyadic_composite", "baseline_composite"),
                   Transparency = c("dyadic_transparent_combined", "baseline_transparent_combined"))
test_table <- do.call(rbind, lapply(names(composites), function(label) {
  columns <- composites[[label]]
  x <- na.omit(d[[columns[1]]]); y <- na.omit(d[[columns[2]]])
  test <- t.test(x, y, paired = FALSE)
  pooled_sd <- sqrt(((length(x)-1)*var(x) + (length(y)-1)*var(y))/(length(x)+length(y)-2))
  data.frame(outcome = label, n_bottleneck = length(x), n_baseline = length(y),
             mean_bottleneck = mean(x), sd_bottleneck = sd(x), mean_baseline = mean(y),
             sd_baseline = sd(y), mean_difference = mean(x)-mean(y),
             t = unname(test$statistic), df = unname(test$parameter), p = test$p.value,
             ci_lower = test$conf.int[1], ci_upper = test$conf.int[2],
             cohen_d = (mean(x)-mean(y))/pooled_sd)
}))
write.csv(test_table, file.path(output_dir, "composite_comparisons.csv"), row.names = FALSE)
write.csv(gender_counts, file.path(output_dir, "gender_counts.csv"), row.names = FALSE)
write.csv(ethnicity_stats, file.path(output_dir, "race_counts.csv"), row.names = FALSE)
write.csv(data.frame(n = nrow(d), age_mean = mean_age, age_sd = sd_age),
          file.path(output_dir, "sample_summary.csv"), row.names = FALSE)
