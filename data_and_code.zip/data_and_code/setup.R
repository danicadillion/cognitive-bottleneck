project_root <- local({
  configured <- getOption("bottleneck.project_root")
  source_files <- unlist(lapply(rev(sys.frames()), function(frame) frame$ofile))
  command_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
  candidates <- unique(c(configured, source_files, command_file, getwd()))
  found <- NULL
  for (candidate in candidates) {
    if (!file.exists(candidate)) next
    directory <- normalizePath(if (dir.exists(candidate)) candidate else dirname(candidate), winslash = "/")
    repeat {
      if (file.exists(file.path(directory, "Cognitive_Bottlenecks.Rproj"))) {
        found <- directory
        break
      }
      parent <- dirname(directory)
      if (identical(parent, directory)) break
      directory <- parent
    }
    if (!is.null(found)) break
  }
  if (is.null(found)) stop("Open Cognitive_Bottlenecks.Rproj or run this script from the extracted project.")
  found
})
source(file.path(project_root, "R", "project_utils.R"), local = TRUE)

if (getRversion() < "4.1.0") stop("R 4.1 or newer is required.")
missing <- project_packages[!vapply(project_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) {
  user_library <- Sys.getenv("R_LIBS_USER")
  if (!nzchar(user_library)) user_library <- file.path(path.expand("~"), "R", "library")
  dir.create(user_library, recursive = TRUE, showWarnings = FALSE)
  .libPaths(c(user_library, .libPaths()))
  install.packages(missing, lib = user_library, repos = "https://cloud.r-project.org")
}
require_packages(project_packages)
message("All required packages are available. Run run_all.R to reproduce the analyses.")
